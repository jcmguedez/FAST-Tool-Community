import React, { useState, useEffect, useRef, Component, ErrorInfo, ReactNode } from 'react';
import mermaid from 'mermaid';
import { 
  Database, 
  Workflow, 
  Users, 
  Copy, 
  Check, 
  Download, 
  RefreshCw, 
  Code2, 
  CalendarRange,
  AlertCircle,
  Calendar,
  Sparkles
} from 'lucide-react';
import { Entidad } from './GestionEntidades';
import { TareaGantt } from './GestionGantt';

interface Proceso {
  id: number;
  proyecto_id: number;
  nombre: string;
  descripcion: string | null;
  numero_proceso: string;
}

interface FlujoDato {
  id: number;
  descripcion: string;
  proceso_origen_id: number | null;
  proceso_destino_id: number | null;
  entidad_id: number | null;
  proceso_origen_nombre?: string;
  proceso_origen_num?: string;
  proceso_destino_nombre?: string;
  proceso_destino_num?: string;
  entidad_nombre?: string;
}

interface Puesto {
  id: number;
  proyecto_id: number;
  nombre: string;
  descripcion: string | null;
}

interface ConexionPuesto {
  id: number;
  tipo_conexion: string;
  puesto_origen_id: number;
  puesto_destino_id: number;
  puesto_origen_nombre?: string;
  puesto_destino_nombre?: string;
}

interface GeneradorDiagramasProps {
  proyectoId: number;
  proyectoNombre?: string;
  entidades: Entidad[];
  procesos: Proceso[];
  flujos: FlujoDato[];
  puestos: Puesto[];
  conexiones: ConexionPuesto[];
  tareasGantt?: TareaGantt[];
}

type TabType = 'erd' | 'dfd' | 'dcp' | 'gantt';

// =========================================================================
// 1. ErrorBoundary para aislar fallos de renderizado de Mermaid.js
// =========================================================================
interface ErrorBoundaryProps {
  children: ReactNode;
  fallbackKey?: string;
  onReset?: () => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class MermaidErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { 
      hasError: true, 
      errorMessage: error?.message || 'Error desconocido al renderizar el gráfico' 
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('MermaidErrorBoundary capturó una excepción en Mermaid.js:', error, errorInfo);
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps) {
    // Si el usuario cambia de pestaña, reiniciar automáticamente el estado de error
    if (prevProps.fallbackKey !== this.props.fallbackKey && this.state.hasError) {
      this.setState({ hasError: false, errorMessage: '' });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 text-center text-xs text-rose-300 max-w-lg bg-rose-950/20 border border-rose-900/50 rounded-2xl mx-auto my-8 space-y-3 shadow-xl">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mx-auto text-rose-400">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">No se pudo generar el diagrama</h4>
            <p className="text-slate-400 text-xs mt-1">
              Mermaid no pudo procesar los datos de este diagrama (posible fecha inválida o caracteres no admitidos).
            </p>
          </div>
          {this.state.errorMessage && (
            <div className="p-2 bg-slate-950/80 rounded-lg text-[11px] font-mono text-rose-400/90 max-h-24 overflow-auto border border-rose-900/30">
              {this.state.errorMessage}
            </div>
          )}
          <button
            onClick={() => {
              this.setState({ hasError: false, errorMessage: '' });
              this.props.onReset?.();
            }}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold transition cursor-pointer inline-flex items-center gap-2 shadow-lg shadow-rose-900/20"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reintentar Diagrama</span>
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// =========================================================================
// 2. Componente de Lienzo Mermaid aislado con gestión de ciclo de vida del DOM
// =========================================================================
interface DiagramCanvasProps {
  activeTab: TabType;
  code: string;
  isEmpty: boolean;
  emptyTitle: string;
  emptySubtitle: string;
  onSvgRendered: (svg: string) => void;
  renderTrigger: number;
}

function DiagramCanvas({
  activeTab,
  code,
  isEmpty,
  emptyTitle,
  emptySubtitle,
  onSvgRendered,
  renderTrigger
}: DiagramCanvasProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isRendering, setIsRendering] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    // Si está vacío, limpiamos el contenedor y no forzamos a Mermaid
    if (isEmpty || !code.trim()) {
      if (mountRef.current) mountRef.current.innerHTML = '';
      onSvgRendered('');
      setLocalError(null);
      setIsRendering(false);
      return;
    }

    const renderGraph = async () => {
      // Generar ID único para evitar colisiones en document.body con Mermaid
      const uniqueId = `mmd_${activeTab}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      try {
        setIsRendering(true);
        setLocalError(null);

        // Llamar a mermaid.render
        const { svg } = await mermaid.render(uniqueId, code);

        if (isMounted) {
          if (mountRef.current) {
            // Inyectar SVG limpiamente sin conflicto con el reconciliador de React
            mountRef.current.innerHTML = svg;
          }
          onSvgRendered(svg);
        }
      } catch (err: any) {
        console.error(`Error al compilar diagrama Mermaid (${activeTab}):`, err);
        if (isMounted) {
          setLocalError(err?.message || 'No se pudo generar el diagrama. Verifica los datos ingresados o el formato de fecha.');
          if (mountRef.current) mountRef.current.innerHTML = '';
          onSvgRendered('');
        }
      } finally {
        // Limpieza de elementos huérfanos generados fuera de nuestro contenedor
        // NUNCA eliminar el SVG que acabamos de montar dentro de mountRef
        const orphan1 = document.getElementById(uniqueId);
        if (orphan1 && !mountRef.current?.contains(orphan1)) {
          orphan1.remove();
        }
        const orphan2 = document.getElementById('d' + uniqueId);
        if (orphan2 && !mountRef.current?.contains(orphan2)) {
          orphan2.remove();
        }

        if (isMounted) setIsRendering(false);
      }
    };

    renderGraph();

    return () => {
      isMounted = false;
      if (mountRef.current) {
        mountRef.current.innerHTML = '';
      }
    };
  }, [code, activeTab, isEmpty, renderTrigger]);

  if (isEmpty) {
    return (
      <div className="text-center p-10 max-w-md mx-auto space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
          {activeTab === 'gantt' && <CalendarRange className="w-6 h-6 text-indigo-400" />}
          {activeTab === 'erd' && <Database className="w-6 h-6 text-cyan-400" />}
          {activeTab === 'dfd' && <Workflow className="w-6 h-6 text-amber-400" />}
          {activeTab === 'dcp' && <Users className="w-6 h-6 text-emerald-400" />}
        </div>
        <h4 className="text-sm font-bold text-white">{emptyTitle}</h4>
        <p className="text-xs text-slate-400 leading-relaxed">{emptySubtitle}</p>
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col items-center justify-center min-h-[420px]">
      {isRendering && (
        <div className="flex flex-col items-center gap-2 text-xs text-slate-400 my-8">
          <RefreshCw className="w-5 h-5 animate-spin text-indigo-400" />
          <span>Compilando diagrama con Mermaid.js...</span>
        </div>
      )}

      {localError && !isRendering && (
        <div className="p-6 text-center text-xs text-rose-300 max-w-md bg-rose-950/20 border border-rose-900/40 rounded-xl my-6">
          <AlertCircle className="w-5 h-5 text-rose-400 mx-auto mb-2" />
          <div className="font-semibold text-white">No se pudo generar el diagrama</div>
          <p className="text-slate-400 text-[11px] mt-1">{localError}</p>
        </div>
      )}

      {/* Contenedor donde se inserta el SVG renderizado */}
      <div 
        ref={mountRef}
        className={`w-full flex items-center justify-center overflow-auto p-4 [&_svg]:max-w-full [&_svg]:h-auto [&_svg]:drop-shadow-lg ${isRendering ? 'hidden' : 'block'}`}
      />
    </div>
  );
}

// =========================================================================
// 3. Componente Principal: GeneradorDiagramas
// =========================================================================
export default function GeneradorDiagramas({
  proyectoId,
  proyectoNombre,
  entidades,
  procesos,
  flujos,
  puestos,
  conexiones,
  tareasGantt = []
}: GeneradorDiagramasProps) {
  const [activeTab, setActiveTab] = useState<TabType>('erd');
  const [svgContent, setSvgContent] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [showCode, setShowCode] = useState<boolean>(false);
  const [renderTrigger, setRenderTrigger] = useState<number>(0);
  const [localTareasGantt, setLocalTareasGantt] = useState<TareaGantt[]>(tareasGantt);

  // Sincronizar o consultar tareas si vienen vacías
  useEffect(() => {
    if (tareasGantt && tareasGantt.length > 0) {
      setLocalTareasGantt(tareasGantt);
    } else if (proyectoId) {
      fetch(`/api/gantt/${proyectoId}`)
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data) && data.length > 0) {
            setLocalTareasGantt(data);
          }
        })
        .catch((err) => console.error('Error cargando tareas para Gantt:', err));
    }
  }, [tareasGantt, proyectoId]);

  // Inicializar Mermaid de forma segura una sola vez con soporte visual para Gantt
  useEffect(() => {
    mermaid.initialize({
      startOnLoad: false,
      theme: 'dark',
      securityLevel: 'loose',
      themeVariables: {
        darkMode: true,
        background: '#090d16',
        primaryColor: '#4f46e5',
        primaryTextColor: '#f8fafc',
        primaryBorderColor: '#6366f1',
        lineColor: '#818cf8',
        secondaryColor: '#1e1b4b',
        tertiaryColor: '#0f172a',
        sectionBkgColor: '#1e1b4b',
        altSectionBkgColor: '#0f172a',
        taskBorderColor: '#6366f1',
        taskBkgColor: '#4f46e5',
        taskTextColor: '#ffffff',
        taskTextLightColor: '#ffffff',
        taskTextOutsideColor: '#cbd5e1',
        taskTextDarkColor: '#ffffff',
        activeTaskBorderColor: '#a5b4fc',
        activeTaskBkgColor: '#6366f1',
        gridColor: '#334155',
        todayLineColor: '#ec4899'
      },
      fontFamily: 'ui-sans-serif, system-ui, sans-serif'
    });
  }, []);

  // 1. Generar sintaxis Mermaid para ERD
  const generateERDCode = (): string => {
    if (entidades.length === 0) {
      return `erDiagram\n    PROYECTO_VACIO {\n        string mensaje "Agrega entidades para generar el DER"\n    }`;
    }

    let code = 'erDiagram\n';
    entidades.forEach((ent) => {
      const sanitizedName = ent.nombre.replace(/[^a-zA-Z0-9_]/g, '_');
      code += `    ${sanitizedName} {\n`;
      if (ent.atributos && ent.atributos.length > 0) {
        ent.atributos.forEach((at) => {
          const atName = at.nombre.replace(/[^a-zA-Z0-9_]/g, '_');
          const tipoSimple = at.tipo_dato.split('(')[0].toLowerCase();
          const pkLabel = at.es_clave_primaria ? 'PK' : '';
          code += `        ${tipoSimple} ${atName} ${pkLabel}\n`;
        });
      } else {
        code += `        int id_generico PK\n`;
      }
      code += `    }\n`;
    });

    if (entidades.length > 1) {
      for (let i = 0; i < entidades.length - 1; i++) {
        const entA = entidades[i].nombre.replace(/[^a-zA-Z0-9_]/g, '_');
        const entB = entidades[i + 1].nombre.replace(/[^a-zA-Z0-9_]/g, '_');
        code += `    ${entA} ||--o{ ${entB} : "se relaciona con"\n`;
      }
    }

    return code;
  };

  // 2. Generar sintaxis Mermaid para DFD
  const generateDFDCode = (): string => {
    if (procesos.length === 0) {
      return `flowchart TD\n    A[Sin Procesos] --> B[Agrega procesos para renderizar el DFD]`;
    }

    let code = 'flowchart TD\n';
    code += '    classDef process fill:#1e1b4b,stroke:#6366f1,stroke-width:2px,color:#fff,rx:8,ry:8;\n';
    code += '    classDef entity fill:#0f172a,stroke:#3b82f6,stroke-width:1.5px,color:#93c5fd;\n';

    procesos.forEach((p) => {
      const procId = `P_${p.id}`;
      const safeNum = p.numero_proceso.replace(/["\n]/g, '');
      const safeNom = p.nombre.replace(/["\n]/g, '');
      const label = `"${safeNum}<br/><b>${safeNom}</b>"`;
      code += `    ${procId}(${label}):::process\n`;
    });

    if (flujos.length > 0) {
      flujos.forEach((f) => {
        const safeDesc = f.descripcion ? `|"${f.descripcion.replace(/["\n]/g, '')}"|` : '';
        if (f.proceso_origen_id && f.proceso_destino_id) {
          code += `    P_${f.proceso_origen_id} -->${safeDesc} P_${f.proceso_destino_id}\n`;
        } else if (f.proceso_origen_id && f.entidad_id) {
          const entId = `E_${f.entidad_id}`;
          const safeEnt = (f.entidad_nombre || 'Almacén de Datos').replace(/["\n]/g, '');
          code += `    ${entId}[("${safeEnt}")]:::entity\n`;
          code += `    P_${f.proceso_origen_id} -->${safeDesc} ${entId}\n`;
        } else if (f.entidad_id && f.proceso_destino_id) {
          const entId = `E_${f.entidad_id}`;
          const safeEnt = (f.entidad_nombre || 'Entidad Externa').replace(/["\n]/g, '');
          code += `    ${entId}[("${safeEnt}")]:::entity\n`;
          code += `    ${entId} -->${safeDesc} P_${f.proceso_destino_id}\n`;
        }
      });
    } else if (procesos.length > 1) {
      for (let i = 0; i < procesos.length - 1; i++) {
        code += `    P_${procesos[i].id} -.->|"flujo sugerido"| P_${procesos[i + 1].id}\n`;
      }
    }

    return code;
  };

  // 3. Generar sintaxis Mermaid para DCP
  const generateDCPCode = (): string => {
    if (puestos.length === 0) {
      return `graph LR\n    A[Sin Puestos] --> B[Registra puestos de trabajo para visualizar el DCP]`;
    }

    let code = 'graph LR\n';
    code += '    classDef puesto fill:#0f172a,stroke:#10b981,stroke-width:2px,color:#fff;\n';

    puestos.forEach((p) => {
      const pId = `PST_${p.id}`;
      const safeNom = p.nombre.replace(/["\n]/g, '');
      const safeDesc = (p.descripcion || 'Puesto de Trabajo').replace(/["\n]/g, '');
      code += `    ${pId}["<b>${safeNom}</b><br/><small>${safeDesc}</small>"]:::puesto\n`;
    });

    if (conexiones.length > 0) {
      conexiones.forEach((c) => {
        const safeTipo = c.tipo_conexion ? `|"${c.tipo_conexion.replace(/["\n]/g, '')}"|` : '';
        code += `    PST_${c.puesto_origen_id} ==> ${safeTipo} PST_${c.puesto_destino_id}\n`;
      });
    } else if (puestos.length > 1) {
      for (let i = 0; i < puestos.length - 1; i++) {
        code += `    PST_${puestos[i].id} ==>|"Canal Administrativo"| PST_${puestos[i + 1].id}\n`;
      }
    }

    return code;
  };

  // 4. Generar sintaxis Mermaid para Cronograma (Gantt) según requerimiento exacto
  const generateGanttCode = (): string => {
    // Si el arreglo de tareas está vacío, devuelve estrictamente el texto solicitado
    if (!localTareasGantt || localTareasGantt.length === 0) {
      return `gantt\n    dateFormat YYYY-MM-DD\n    title Sin tareas`;
    }

    let code = 'gantt\n';
    code += '    dateFormat YYYY-MM-DD\n';
    code += '    title Cronograma Metodológico FAST\n';
    code += '    axisFormat %Y-%m-%d\n';

    // Agrupar tareas por fase_asociada
    const fasesMap = new Map<string, TareaGantt[]>();
    localTareasGantt.forEach((t) => {
      const fase = (t.fase_asociada || 'Fase General').trim();
      if (!fasesMap.has(fase)) {
        fasesMap.set(fase, []);
      }
      fasesMap.get(fase)!.push(t);
    });

    let taskIndex = 1;
    fasesMap.forEach((tasksInFase, faseName) => {
      const cleanFase = faseName.replace(/[:;#\n]/g, ' ').trim() || 'Fase';
      code += `\n    section ${cleanFase}\n`;
      tasksInFase.forEach((t) => {
        // Limpiar nombre de caracteres que rompen la gramática de Mermaid
        const cleanName = (t.nombre_tarea || 'Tarea')
          .replace(/[:;#\n",]/g, ' ')
          .trim();

        // Validar formato de fecha YYYY-MM-DD
        let validDate = (t.fecha_inicio || '').trim();
        if (!/^\d{4}-\d{2}-\d{2}$/.test(validDate)) {
          validDate = new Date().toISOString().split('T')[0];
        }

        // Validar duración
        const dur = Math.max(1, parseInt(String(t.duracion_dias), 10) || 1);
        const taskId = `a${t.id || taskIndex++}`;
        code += `    ${cleanName} :${taskId}, ${validDate}, ${dur}d\n`;
      });
    });

    return code;
  };

  // Cálculo síncrono del código Mermaid para garantizar consistencia inmediata entre activeTab y el código
  const mermaidCode = React.useMemo(() => {
    if (activeTab === 'erd') {
      return generateERDCode();
    } else if (activeTab === 'dfd') {
      return generateDFDCode();
    } else if (activeTab === 'dcp') {
      return generateDCPCode();
    } else if (activeTab === 'gantt') {
      return generateGanttCode();
    }
    return '';
  }, [activeTab, entidades, procesos, flujos, puestos, conexiones, localTareasGantt, proyectoNombre]);

  // Manejador de copia al portapapeles
  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(mermaidCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Descarga del SVG generado
  const handleDownloadSVG = () => {
    if (!svgContent) return;
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `diagrama-${activeTab}-${proyectoId}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Verificación de datos vacíos por pestaña
  const isTabEmpty = (activeTab === 'gantt' && (!localTareasGantt || localTareasGantt.length === 0)) ||
                     (activeTab === 'erd' && entidades.length === 0) ||
                     (activeTab === 'dfd' && procesos.length === 0) ||
                     (activeTab === 'dcp' && puestos.length === 0);

  const getEmptyInfo = () => {
    switch (activeTab) {
      case 'gantt':
        return {
          title: 'Cronograma sin tareas registradas',
          subtitle: 'Para visualizar el Diagrama de Gantt, dirígete a Fase 1: Cronograma (Gantt) y registra tus actividades o utiliza la plantilla FAST.'
        };
      case 'erd':
        return {
          title: 'Modelo ERD sin entidades',
          subtitle: 'Agrega entidades y atributos en la Fase 2 (Estudio del Sistema) para generar el diagrama relacional.'
        };
      case 'dfd':
        return {
          title: 'DFD sin procesos definidos',
          subtitle: 'Define procesos y flujos en la Fase 2 para visualizar el flujo de datos del sistema.'
        };
      case 'dcp':
        return {
          title: 'DCP sin puestos de trabajo',
          subtitle: 'Registra los puestos y canales de comunicación organizacionales en la Fase 2.'
        };
    }
  };

  const emptyInfo = getEmptyInfo();

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl space-y-0">
      {/* Barra de control y navegación de pestañas */}
      <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Selector de pestañas */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 flex-wrap">
          <button
            onClick={() => setActiveTab('erd')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'erd' ? 'bg-indigo-600 text-white shadow-xs font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Modelo ERD (DER)</span>
          </button>

          <button
            onClick={() => setActiveTab('dfd')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'dfd' ? 'bg-indigo-600 text-white shadow-xs font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Workflow className="w-3.5 h-3.5" />
            <span>Flujo de Datos (DFD)</span>
          </button>

          <button
            onClick={() => setActiveTab('dcp')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'dcp' ? 'bg-indigo-600 text-white shadow-xs font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Conexión de Puestos (DCP)</span>
          </button>

          <button
            onClick={() => setActiveTab('gantt')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'gantt' ? 'bg-indigo-600 text-white shadow-xs font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CalendarRange className="w-3.5 h-3.5" />
            <span>Cronograma (Gantt)</span>
          </button>
        </div>

        {/* Acciones: Ver código, Copiar, Descargar SVG */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCode(!showCode)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition flex items-center gap-1.5 cursor-pointer ${
              showCode
                ? 'bg-slate-800 border-indigo-500/50 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{showCode ? 'Ocultar Código' : 'Ver Código Mermaid'}</span>
          </button>

          <button
            onClick={handleCopyCode}
            className="px-3 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">¡Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copiar Mermaid</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadSVG}
            disabled={!svgContent}
            className="px-3 py-1.5 text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Exportar SVG</span>
          </button>
        </div>
      </div>

      {/* Editor / Vista de código Mermaid opcional */}
      {showCode && (
        <div className="p-4 bg-slate-950/90 border-b border-slate-800 font-mono text-xs text-indigo-300 overflow-x-auto max-h-48 leading-relaxed">
          <pre>{mermaidCode}</pre>
        </div>
      )}

      {/* ========================================================================= */}
      {/* Lienzo del Diagrama protegido por ErrorBoundary y con key={activeTab}      */}
      {/* El atributo key={activeTab} obliga a React a destruir y recrear el DOM    */}
      {/* eliminando el error 'Failed to execute removeChild on Node'.              */}
      {/* ========================================================================= */}
      <MermaidErrorBoundary fallbackKey={activeTab} onReset={() => setRenderTrigger((prev) => prev + 1)}>
        <div 
          key={activeTab}
          className="p-8 min-h-[480px] bg-slate-950 flex items-center justify-center overflow-auto relative"
        >
          <DiagramCanvas
            activeTab={activeTab}
            code={mermaidCode}
            isEmpty={isTabEmpty}
            emptyTitle={emptyInfo.title}
            emptySubtitle={emptyInfo.subtitle}
            onSvgRendered={(svg) => setSvgContent(svg)}
            renderTrigger={renderTrigger}
          />
        </div>
      </MermaidErrorBoundary>

      {/* Pie descriptivo del diagrama */}
      <div className="px-6 py-3 bg-slate-950 border-t border-slate-800/80 text-[11px] text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span className="font-semibold text-slate-400">Tipo de Diagrama:</span>{' '}
          {activeTab === 'erd' && 'Modelo Entidad-Relación (DER) derivado de tablas "entidades" y "atributos".'}
          {activeTab === 'dfd' && 'Diagrama de Flujo de Datos (DFD) nivel de procesos e intercambios.'}
          {activeTab === 'dcp' && 'Diagrama de Conexión de Puestos (DCP) según metodología FAST.'}
          {activeTab === 'gantt' && 'Diagrama de Gantt del cronograma del proyecto organizado por fases metodológicas FAST.'}
        </div>
        <div className="text-slate-400 font-mono text-[10px]">
          Renderizado con aislamiento de DOM · Cero conflictos de reconciliación React
        </div>
      </div>
    </div>
  );
}
