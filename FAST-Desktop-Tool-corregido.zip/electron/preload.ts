import { contextBridge } from 'electron';

// Exponer de forma segura variables o funciones al proceso de renderizado
contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  isElectron: true
});
