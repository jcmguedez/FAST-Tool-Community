import { app, BrowserWindow, dialog, shell } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import { fork, ChildProcess } from 'child_process';
import http from 'http';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let mainWindow: BrowserWindow | null = null;
let serverProcess: ChildProcess | null = null;

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;
const SERVER_PORT = 3000;

/**
 * Inicia automáticamente el servidor Express y asegura que
 * SQLite utilice la carpeta persistente AppData/Roaming en producción.
 */
function startExpressServer(): Promise<void> {
  return new Promise((resolve, reject) => {
    const userDataPath = app.getPath('userData');
    process.env.ELECTRON_USER_DATA = userDataPath;
    process.env.PORT = String(SERVER_PORT);

    // Asegurar existencia del directorio AppData
    if (!fs.existsSync(userDataPath)) {
      fs.mkdirSync(userDataPath, { recursive: true });
    }

    // Ubicación del script del servidor (server.cjs o server.js empaquetado o en desarrollo)
    const packagedAppRoot = path.join(process.resourcesPath, 'app');
    const candidatePaths = [
      ...(app.isPackaged ? [] : [
        path.join(__dirname, '../server.cjs'),
        path.join(__dirname, '../server.js')
      ]),
      path.join(process.resourcesPath, 'app', 'server.cjs'),
      path.join(process.resourcesPath, 'app', 'server.js')
    ];
    const serverScript = candidatePaths.find((p) => fs.existsSync(p));

    if (!serverScript) {
      reject(new Error(`No se encontró el servidor Express. Rutas revisadas: ${candidatePaths.join(', ')}`));
      return;
    }

    console.log(`[Electron Main] Iniciando Express desde: ${serverScript}`);
    console.log(`[Electron Main] Ruta userData SQLite: ${userDataPath}`);

    try {
      serverProcess = fork(serverScript, [], {
        env: {
          ...process.env,
          PORT: String(SERVER_PORT),
          ELECTRON_USER_DATA: userDataPath,
          ELECTRON_APP_ROOT: app.isPackaged ? packagedAppRoot : path.join(__dirname, '..'),
          NODE_PATH: [
            path.join(process.resourcesPath, 'app.asar', 'node_modules'),
            path.join(process.resourcesPath, 'app', 'node_modules'),
            process.env.NODE_PATH || ''
          ].filter(Boolean).join(path.delimiter),
          NODE_ENV: isDev ? 'development' : 'production'
        },
        stdio: 'inherit'
      });

      serverProcess.on('error', (err) => {
        console.error('[Electron Main] Error al ejecutar proceso Express:', err);
        reject(err);
      });
    } catch (error) {
      console.error('[Electron Main] Fallo al iniciar proceso hijo del servidor:', error);
      reject(error);
      return;
    }

    // Esperar a que el servidor Express esté escuchando peticiones
    let retries = 0;
    const checkServerReady = () => {
      const request = http.get(`http://127.0.0.1:${SERVER_PORT}/`, (response) => {
        response.resume();
        if (response.statusCode && response.statusCode >= 200 && response.statusCode < 400) {
          console.log('[Electron Main] Servidor Express e interfaz responden correctamente.');
          resolve();
        } else {
          reject(new Error(`El servidor respondió ${response.statusCode} al cargar la interfaz.`));
        }
      }).on('error', () => {
        retries++;
        if (retries > 60) {
          reject(new Error('Tiempo de espera agotado esperando al servidor Express.'));
        } else {
          setTimeout(checkServerReady, 250);
        }
      });
      request.setTimeout(1000, () => request.destroy());
    };

    checkServerReady();
  });
}

/**
 * Crea la ventana principal de la aplicación con especificaciones exactas (1200x800).
 */
function createMainWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 960,
    minHeight: 640,
    title: 'FAST Desktop Tool',
    backgroundColor: '#020617',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false
    }
  });

  // Cargar URL del servidor Express
  mainWindow.loadURL(`http://127.0.0.1:${SERVER_PORT}/`).catch((error) => {
    console.error('[Electron Main] Error cargando la interfaz:', error);
    dialog.showErrorBox('FAST Desktop Tool', `No se pudo cargar la interfaz.\n\n${error.message}`);
    app.quit();
  });

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription) => {
    console.error(`[Electron Main] did-fail-load ${errorCode}: ${errorDescription}`);
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  // Abrir enlaces externos en el navegador predeterminado del sistema operativo
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http:') || url.startsWith('https:')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Ciclo de vida de la aplicación Electron
app.whenReady().then(async () => {
  try {
    await startExpressServer();
    createMainWindow();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error('[Electron Main] Arranque abortado:', message);
    dialog.showErrorBox('FAST Desktop Tool no pudo iniciar', message);
    app.quit();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('before-quit', () => {
  if (serverProcess) {
    console.log('[Electron Main] Deteniendo servidor Express...');
    serverProcess.kill('SIGTERM');
    serverProcess = null;
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
